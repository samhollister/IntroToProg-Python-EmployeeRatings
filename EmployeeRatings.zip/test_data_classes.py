# ------------------------------------------------------------------------------------------------- #
# Title: Assignment08 - Test Data Classes
# # Description: Performs unit tests for data_classes
# ChangeLog: (Who, When, What)
# SHollister,6/16/25,Created Script
# ------------------------------------------------------------------------------------------------- #

import unittest
from data_classes import Person
from data_classes import Employee

class TestPerson(unittest.TestCase):

    def test_person_init(self): #tests the constructor
        person = Person("John","Doe")
        self.assertEqual(person.first_name, "John")
        self.assertEqual(person.last_name, "Doe")

    def test_person_invalid(self): #test the first/last name validations
        with self.assertRaises(ValueError):
            person = Person("123","Doe")
        with self.assertRaises(ValueError):
            person = Person("John","456")

    def test_person_str(self): #test the __str()__ magic method
        person = Person("John", "Doe")
        self.assertEqual(str(person),"John,Doe")

class TestEmployee(unittest.TestCase):

    def test_employee_init(self): #tests the constructor
        employee = Employee("John","Doe","2025-01-01",3)
        self.assertEqual(employee.first_name, "John")
        self.assertEqual(employee.last_name, "Doe")
        self.assertEqual(employee.review_date, "2025-01-01")
        self.assertEqual(employee.review_rating, 3)

    def test_employee_review_date_type(self): #test the review date type validation
        with self.assertRaises(ValueError):
            employee = Employee("John","Doe","invalid",3)

    def test_employee_review_rating_type(self): #test the review rating type validation
        with self.assertRaises(ValueError):
            employee = Employee("John","Doe","2025-01-01","review")

    def test_employee_str(self): #test the __str()__ magic method
        employee = Employee("John","Doe","2025-01-01",3)
        self.assertEqual(str(employee),"John,Doe,2025-01-01,3")

if __name__ == '__main__':
    unittest.main()
