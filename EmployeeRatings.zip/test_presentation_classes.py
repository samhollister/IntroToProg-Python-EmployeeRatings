# ------------------------------------------------------------------------------------------------- #
# Title: Assignment08 - Test Presentation Classes
# # Description: #todo add description
# ChangeLog: (Who, When, What)
# SHollister,6/16/25,Created Script
# ------------------------------------------------------------------------------------------------- #

import unittest
import data_classes as data
from unittest.mock import patch
from presentation_classes import IO

class TestIO(unittest.TestCase):

    def setUp(self):
        self.employee_data = []

    def test_input_menu_choice(self):
        with patch("builtins.input", return_value = "2"):
            choice = IO.input_menu_choice()
            self.assertEqual(choice, "2")

    def test_input_employee_data(self):
        with patch("builtins.input", side_effect = ["John","Doe","2025-01-01",3]):
            IO.input_employee_data(self.employee_data, data.Employee)
            self.assertEqual(len(self.employee_data),1)
            self.assertEqual(self.employee_data[0].first_name,"John")
            self.assertEqual(self.employee_data[0].last_name, "Doe")
            self.assertEqual(self.employee_data[0].review_date, "2025-01-01")
            self.assertEqual(self.employee_data[0].review_rating, 3)

        #Test invalid date input
        with patch("builtins.input", side_effect = ["John","Doe","01-01-2025",3]):
            IO.input_employee_data(self.employee_data, data.Employee)
            self.assertEqual(len(self.employee_data),1)

        #Test invalid rating input
        with patch("Builtins.input", side_effect = ["John","Doe","2025-01-01","invalid"]):
            IO.input_employee_data(self.employee_data, data.Employee)
            self.assertEqual(len(self.employee_data),1)

if __name__ == "__main__":
    unittest.main()